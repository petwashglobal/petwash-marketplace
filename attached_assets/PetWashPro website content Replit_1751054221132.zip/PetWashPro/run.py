#!/usr/bin/env python3
import http.server
import socketserver
import os
import threading
import time

PORT = int(os.environ.get('PORT', 3000))

class Handler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory='public', **kwargs)
    
    def do_GET(self):
        if self.path == '/health':
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            response = '{"status":"healthy","service":"Pet Wash IL","port":' + str(PORT) + '}'
            self.wfile.write(response.encode())
        else:
            super().do_GET()

def start_server():
    with socketserver.TCPServer(("0.0.0.0", PORT), Handler) as httpd:
        print(f"Pet Wash IL server running on port {PORT}")
        print(f"Health check: http://localhost:{PORT}/health")
        httpd.serve_forever()

if __name__ == "__main__":
    start_server()