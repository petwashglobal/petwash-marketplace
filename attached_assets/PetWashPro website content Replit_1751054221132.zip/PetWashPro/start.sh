#!/bin/bash
cd /home/runner/workspace
python3 -m http.server 3000 --directory public --bind 0.0.0.0