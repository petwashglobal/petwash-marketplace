const express = require('express');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 80;

// Static file serving
app.use(express.static('public'));

// Health endpoint for deployment verification
app.get('/health', (req, res) => {
  res.json({
    status: 'healthy',
    service: 'Pet Wash IL',
    port: PORT,
    timestamp: new Date().toISOString()
  });
});

// SPA fallback route
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Start server
const server = app.listen(PORT, () => {
  console.log(`Pet Wash IL running on port ${PORT}`);
  console.log(`Health check: http://localhost:${PORT}/health`);
});